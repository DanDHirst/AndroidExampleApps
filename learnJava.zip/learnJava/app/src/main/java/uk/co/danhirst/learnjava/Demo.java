package uk.co.danhirst.learnjava;



public class Demo {
    public static void main(String[] args) {
//        Enemy enemy = new Enemy("test enemy", 10,3);
//        enemy.showInfo();
//
//        enemy.takeDamage(3);
//        enemy.showInfo();
//
//        enemy.takeDamage(23);
//        enemy.showInfo();
        Troll uglyTroll = new Troll("Ugly Troll");
        uglyTroll.showInfo();
        uglyTroll.takeDamage(28);

        Vampire vlad = new Vampire("Vlad");
        vlad.showInfo();
        vlad.takeDamage(8);
        vlad.showInfo();

        VampireKing vamp = new VampireKing("King");
        vamp.showInfo();
        vamp.takeDamage(10);
        vamp.showInfo();

    }

}
