package uk.co.danhirst.learnjava;

public class VampireKing extends Vampire{
    public VampireKing(String name) {
        super(name);
        setHitPoints(140);
    }

    @Override
    public void takeDamage(int damage) {
        int damageDone = damage/2;
        super.takeDamage(damageDone);
    }
}
