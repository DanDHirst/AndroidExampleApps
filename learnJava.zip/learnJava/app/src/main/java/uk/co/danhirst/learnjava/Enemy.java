package uk.co.danhirst.learnjava;

public class Enemy {
    private String name;
    private int hitPoints;
    private int lives;

    public Enemy(String name, int hitPoints, int lives) {
        this.name = name;
        this.hitPoints = hitPoints;
        this.lives = lives;
    }

    public void takeDamage(int damage){
        int remianingHitPoints = this.hitPoints - damage;
        if (remianingHitPoints > 0){
            setHitPoints(remianingHitPoints);
            System.out.println("i took " + damage + " points damage, and have " + remianingHitPoints+ " Left.");
        }
        else{
            this.lives = this.lives - 1 ;
            if(lives > 0){
                System.out.println("lost a life "+ this.lives + " lives left");
            }
            else{
                System.out.println("Game over!");
            }

        }
    }

    public void showInfo(){
        System.out.println("Name: "+ this.name + " Hitpoints: " + this.hitPoints + " Lives: " + this.lives);
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getHitPoints() {
        return hitPoints;
    }

    public void setHitPoints(int hitPoints) {
        this.hitPoints = hitPoints;
    }

    public int getLives() {
        return lives;
    }

    public void setLives(int lives) {
        this.lives = lives;
    }
}
