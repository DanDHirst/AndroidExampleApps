package uk.co.danhirst.learnjava;

import java.util.ArrayList;

public class Player {
    //field values
    private String handleName;
    private int lives;
    private int level;
    private int score;
    private Weapon weapon;
    private ArrayList<Loot> inventory;

    //contructors
    public Player(){
        this("Unknown Player");//calls the other constructor with the handle of unknown player

    }

    public Player(String handle){
        this(handle,1);
      //  handleName = handle;
      //  lives = 3;
      //  level = 1;
      //  score = 0;
    }

    public Player(String handle, int startingLevel){
       // this.handleName = handle;
       // this.lives = 3;
      //  this.level = startingLevel;
       // this.score = 0;
        setHandleName(handle);
        setLives(3);
        setLevel(startingLevel);
        setScore(0);
        setDefaultWeapon();
        inventory = new ArrayList<>();

    }
    //setter and getter for handle name
    public String getHandleName(){
        return handleName;
    }

    public void setHandleName(String handle){
        if(handle.length() < 1){
            System.out.println("handle name is empty!");
            return;
        }
        this.handleName = handle;

    }
    private void setDefaultWeapon(){
        this.weapon = new Weapon("Sword", 10, 20);
    }

    public void setNameAndLevel(String name, int level){
      /*  this.handleName = name;
       this.level = level;*/
      setHandleName(name);
      setLevel(level);

    }
    //setter and getter for level use alt + insert
    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }
    //setter and getter for level use alt + insert

    public int getLives() {
        return lives;
    }

    public void setLives(int lives) {
        this.lives = lives;
    }
    //setter and getter for level use alt + insert

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public Weapon getWeapon() {
        return weapon;
    }

    public void setWeapon(Weapon weapon) {
        this.weapon = weapon;
    }

    public ArrayList<Loot> getInventory() {
        return inventory;
    }

//    public void setInventory(ArrayList<Loot> inventory) {
//        this.inventory = inventory;
//    }
    public void pickUpLoot(Loot newLoot){
        inventory.add(newLoot);
    }
    public boolean dropLoot(Loot loot){
        if(this.inventory.contains(loot)){
            inventory.remove(loot);
            return true;
        }
        return false;
    }

    public void showInventory(){
        System.out.println("==============Inventory============");
        for (Loot item : inventory){
            System.out.println(item.getName());
        }
        System.out.println("===================================");
    }
}
