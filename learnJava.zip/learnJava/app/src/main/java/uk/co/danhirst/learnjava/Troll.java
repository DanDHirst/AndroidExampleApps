package uk.co.danhirst.learnjava;

public class Troll extends Enemy {
    public Troll(String name) {
        super(name,27,1);
    }
}

